#include <thread>
#include <iostream>
#include <vector>
#include <cstdlib>

extern "C" void __ft_thread_begin();
extern "C" void __ft_thread_end();

volatile int counter = 0;

void writer() {
    __ft_thread_begin();
    for (int i = 0; i < 1000; i++) {
        counter++;   // potential W-W race
    }
    __ft_thread_end();
}

void reader() {
    __ft_thread_begin();
    for (int i = 0; i < 1000; i++) {
        int tmp = counter; // potential R-W race
        (void)tmp;
    }
    __ft_thread_end();
}

int main() {
    std::thread t1(writer);
    std::thread t2(reader);

    t1.join();
    t2.join();
}
