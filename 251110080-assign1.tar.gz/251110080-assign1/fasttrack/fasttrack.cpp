#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <pthread.h>
#include <unordered_map>

using Address = unsigned long long;
using Word = unsigned long;


const size_t MAX_WORKERS = 16;
const size_t SHARD_MASK = 1023; 


struct Timestamp {
    unsigned long long raw;
    Timestamp() : raw(0) {}
    Timestamp(unsigned long long v) : raw(v) {}
    Timestamp(unsigned int id, unsigned int count) 
        : raw(((unsigned long long)id << 32) | count) {}

    inline unsigned int get_id() const { return raw >> 32; }
    inline unsigned int get_count() const { return (unsigned int)(raw & 0xFFFFFFFFULL); }
};

struct ClockArray {
    unsigned int entries[MAX_WORKERS];

    ClockArray(unsigned int base = 0) {
        for (size_t i = 0; i < MAX_WORKERS; ++i) entries[i] = base;
    }

    inline unsigned int get(unsigned int id) const { return entries[id]; }
    inline void set(unsigned int id, unsigned int val) { entries[id] = val; }
    inline void inc(unsigned int id) { entries[id]++; }

   
    inline bool covers(Timestamp ts) const {
        return entries[ts.get_id()] >= ts.get_count();
    }

    void absorb(const ClockArray &other) {
        for (size_t i = 0; i < MAX_WORKERS; ++i) {
            if (other.entries[i] > entries[i]) entries[i] = other.entries[i];
        }
    }
};

struct SyncObject {
    ClockArray clock;
    SyncObject() : clock(0) {}
};

struct MemoryCell {
    std::atomic<unsigned long long> last_write;
    std::atomic<unsigned long long> last_read;
    ClockArray* shared_readers;
    unsigned long long write_pc = 0;
    unsigned long long read_pc = 0;
    bool multi_reader = false;

    MemoryCell() : last_write(0), last_read(0), shared_readers(nullptr) {}

    void promote_to_shared(unsigned int r1, unsigned int c1, unsigned int r2, unsigned int c2) {
        if (!shared_readers) shared_readers = new ClockArray();
        shared_readers->set(r1, c1);
        shared_readers->set(r2, c2);
        multi_reader = true;
    }
};

struct alignas(64) WorkerContext {
    ClockArray vc;
    Timestamp current_ts;

    WorkerContext() : vc(0), current_ts(0, 0) {}

    void boot(unsigned int id) {
        vc.set(id, 1);
        current_ts = Timestamp(id, 1);
    }

    void step() {
        unsigned int id = current_ts.get_id();
        vc.inc(id);
        current_ts = Timestamp(id, vc.get(id));
    }
};

struct DataShard {
    pthread_spinlock_t guard;
    std::unordered_map<Address, MemoryCell> shadow_mem;
    std::unordered_map<Address, SyncObject> sync_mem;

    DataShard() { pthread_spin_init(&guard, PTHREAD_PROCESS_PRIVATE); }
    ~DataShard() { pthread_spin_destroy(&guard); }
};

class RaceEngine {
    DataShard bins[SHARD_MASK + 1];
    WorkerContext workers[MAX_WORKERS];

    inline size_t hash_addr(Address a) const { return (a >> 3) & SHARD_MASK; }

    void report_violation(const char* tag, Address addr, unsigned long long pc1, 
                          unsigned long long pc2, unsigned int t1, unsigned int t2) {
        const char* src1 = pc1 ? (const char*)pc1 : "unknown";
        const char* src2 = pc2 ? (const char*)pc2 : "unknown";

        printf("\n!!! DATA RACE [%s] at %llx !!!\n", tag, addr);
        printf("  Thread %u access at: %s\n", t1, src1);
        printf("  Thread %u access at: %s\n", t2, src2);
        printf("--------------------------------------\n");
    }

public:
    RaceEngine() { workers[0].boot(0); }

    void setup_worker(unsigned int id) { workers[id].boot(id); }

    void on_read(unsigned int tid, Address addr, unsigned long long pc) {
        WorkerContext &ctx = workers[tid];
        DataShard &bin = bins[hash_addr(addr)];
        
        pthread_spin_lock(&bin.guard);
        MemoryCell &cell = bin.shadow_mem[addr];

        Timestamp r_ts(cell.last_read.load());
        if (r_ts.raw == ctx.current_ts.raw) {
            pthread_spin_unlock(&bin.guard);
            return;
        }

        Timestamp w_ts(cell.last_write.load());
        if (w_ts.get_id() != tid && w_ts.get_id() != 0) {
            if (!ctx.vc.covers(w_ts)) {
                report_violation("Write-Read", addr, cell.write_pc, pc, w_ts.get_id(), tid);
            }
        }

        if (cell.multi_reader) {
            cell.shared_readers->set(tid, ctx.current_ts.get_count());
        } else {
            if (ctx.vc.covers(r_ts)) {
                cell.last_read.store(ctx.current_ts.raw);
                cell.read_pc = pc;
            } else {
                cell.promote_to_shared(r_ts.get_id(), r_ts.get_count(), tid, ctx.current_ts.get_count());
            }
        }
        pthread_spin_unlock(&bin.guard);
    }

    void on_write(unsigned int tid, Address addr, unsigned long long pc) {
        WorkerContext &ctx = workers[tid];
        DataShard &bin = bins[hash_addr(addr)];

        pthread_spin_lock(&bin.guard);
        MemoryCell &cell = bin.shadow_mem[addr];

        Timestamp w_ts(cell.last_write.load());
        if (w_ts.raw == ctx.current_ts.raw) {
            pthread_spin_unlock(&bin.guard);
            return;
        }

        if (w_ts.get_id() != tid && w_ts.get_id() != 0) {
            if (!ctx.vc.covers(w_ts)) {
                report_violation("Write-Write", addr, cell.write_pc, pc, w_ts.get_id(), tid);
            }
        }

        if (cell.multi_reader) {
            for (unsigned int i = 0; i < MAX_WORKERS; ++i) {
                if (i != tid && cell.shared_readers->get(i) > ctx.vc.get(i)) {
                    report_violation("Read-Write (Shared)", addr, cell.read_pc, pc, i, tid);
                }
            }
            cell.multi_reader = false;
        } else {
            Timestamp r_ts(cell.last_read.load());
            if (r_ts.get_id() != 0 && r_ts.get_id() != tid) {
                if (!ctx.vc.covers(r_ts)) {
                    report_violation("Read-Write (Exclusive)", addr, cell.read_pc, pc, r_ts.get_id(), tid);
                }
            }
        }

        cell.last_write.store(ctx.current_ts.raw);
        cell.write_pc = pc;
        pthread_spin_unlock(&bin.guard);
    }

    void acquire_lock(unsigned int tid, Address lock_addr) {
        WorkerContext &ctx = workers[tid];
        DataShard &bin = bins[hash_addr(lock_addr)];
        pthread_spin_lock(&bin.guard);
        ctx.vc.absorb(bin.sync_mem[lock_addr].clock);
        pthread_spin_unlock(&bin.guard);
    }

    void release_lock(unsigned int tid, Address lock_addr) {
        WorkerContext &ctx = workers[tid];
        DataShard &bin = bins[hash_addr(lock_addr)];
        pthread_spin_lock(&bin.guard);
        bin.sync_mem[lock_addr].clock = ctx.vc;
        ctx.step();
        pthread_spin_unlock(&bin.guard);
    }

    ClockArray fork_parent(unsigned int tid) {
        workers[tid].step();
        return workers[tid].vc;
    }

    void join_child(unsigned int tid, unsigned int target_child) {
        workers[tid].vc.absorb(workers[target_child].vc);
        workers[tid].step();
    }

    void start_child(unsigned int tid, const ClockArray &p_vc) {
        workers[tid].vc = p_vc;
        workers[tid].boot(tid);
        workers[tid].vc.set(tid, 1);
    }
};

// --- Runtime Global State ---
static RaceEngine engine;
static std::atomic<unsigned int> next_id(1);
static thread_local unsigned int local_tid = 0;
static thread_local bool tid_set = false;

inline unsigned int fetch_tid() {
    if (!tid_set) {
        if (local_tid == 0) {
            static std::atomic_flag main_init = ATOMIC_FLAG_INIT;
            if (!main_init.test_and_set()) {
                local_tid = 0;
                engine.setup_worker(0);
            } else {
                local_tid = next_id.fetch_add(1);
            }
        }
        tid_set = true;
    }
    return local_tid;
}


extern "C" {
    void __ft_read(void *a, unsigned long long ip) { engine.on_read(fetch_tid(), (Address)a, ip); }
    void __ft_write(void *a, unsigned long long ip) { engine.on_write(fetch_tid(), (Address)a, ip); }
    void __ft_lock(void *a, unsigned long long ip) { (void)ip; engine.acquire_lock(fetch_tid(), (Address)a); }
    void __ft_unlock(void *a, unsigned long long ip) { (void)ip; engine.release_lock(fetch_tid(), (Address)a); }

    struct ThreadInfo { pthread_t handle; unsigned int id; bool in_use; };
    static ThreadInfo Registry[MAX_WORKERS];
    static pthread_spinlock_t reg_lock;
    static bool reg_init = false;

    struct SpawnBridge {
        void* (*fn)(void*);
        void* payload;
        unsigned int cid;
        ClockArray parent_clocks;
    };

    void* thread_bridge(void* data) {
        SpawnBridge *sb = (SpawnBridge*)data;
        local_tid = sb->cid;
        tid_set = true;
        engine.start_child(local_tid, sb->parent_clocks);
        void* res = sb->fn(sb->payload);
        delete sb;
        return res;
    }

    int pthread_create(pthread_t *t, const pthread_attr_t *a, void *(*f)(void*), void *arg) {
        if (!reg_init) { pthread_spin_init(&reg_lock, 0); reg_init = true; }
        
        unsigned int pid = fetch_tid();
        unsigned int cid = next_id.fetch_add(1);
        ClockArray p_vc = engine.fork_parent(pid);
        SpawnBridge *bridge = new SpawnBridge{f, arg, cid, p_vc};
        
        auto real_create = (int(*)(pthread_t*, const pthread_attr_t*, void*(*)(void*), void*))dlsym(RTLD_NEXT, "pthread_create");
        int status = real_create(t, a, thread_bridge, bridge);
        
        if (status == 0) {
            pthread_spin_lock(&reg_lock);
            for (int i = 0; i < MAX_WORKERS; i++) {
                if (!Registry[i].in_use) { Registry[i] = {*t, cid, true}; break; }
            }
            pthread_spin_unlock(&reg_lock);
        }
        return status;
    }

    int pthread_join(pthread_t t, void **r) {
        if (!reg_init) { pthread_spin_init(&reg_lock, 0); reg_init = true; }
        auto real_join = (int(*)(pthread_t, void**))dlsym(RTLD_NEXT, "pthread_join");
        int status = real_join(t, r);
        
        if (status == 0) {
            pthread_spin_lock(&reg_lock);
            for (int i = 0; i < MAX_WORKERS; i++) {
                if (Registry[i].in_use && pthread_equal(Registry[i].handle, t)) {
                    engine.join_child(fetch_tid(), Registry[i].id);
                    Registry[i].in_use = false;
                    break;
                }
            }
            pthread_spin_unlock(&reg_lock);
        }
        return status;
    }
}
