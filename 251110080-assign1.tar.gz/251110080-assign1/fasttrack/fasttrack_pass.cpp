#include "llvm/IR/DebugInfoMetadata.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Module.h"
#include "llvm/Pass.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;

namespace {

struct RaceDetectorPass : public PassInfoMixin<RaceDetectorPass> {
  PreservedAnalyses run(Module &Mod, ModuleAnalysisManager &MAM) {
    auto &Context = Mod.getContext();
    
    Type *Void = Type::getVoidTy(Context);
    PointerType *GenericPtr = PointerType::get(Context, 0);
    IntegerType *Int64 = Type::getInt64Ty(Context);

    FunctionCallee MemRead = Mod.getOrInsertFunction("__ft_read", Void, GenericPtr, Int64);
    FunctionCallee MemWrite = Mod.getOrInsertFunction("__ft_write", Void, GenericPtr, Int64);
    FunctionCallee SyncLock = Mod.getOrInsertFunction("__ft_lock", Void, GenericPtr, Int64);
    FunctionCallee SyncUnlock = Mod.getOrInsertFunction("__ft_unlock", Void, GenericPtr, Int64);

    for (Function &F : Mod) {
      if (F.isDeclaration()) continue;

      for (BasicBlock &BB : F) {
        for (Instruction &I : BB) {
          
          auto CreateInstMetadata = [&](Instruction *Target, IRBuilder<> &Bld) -> Value* {
            std::string Buffer;
            raw_string_ostream Stream(Buffer);
            Target->print(Stream);
            
            if (!Buffer.empty() && Buffer.back() == '\n') Buffer.pop_back();

            Constant *GlobalStr = Bld.CreateGlobalString(Buffer, "ft_instr_ptr");
            return Bld.CreatePtrToInt(GlobalStr, Int64);
          };

          if (auto *Call = dyn_cast<CallBase>(&I)) {
            Function *Callee = Call->getCalledFunction();
            if (Callee) {
              StringRef FuncName = Callee->getName();

              bool isLocking = (FuncName == "pthread_mutex_lock") || 
                              (FuncName.contains("mutex") && FuncName.contains("lock") && !FuncName.contains("unlock"));
              
              bool isUnlocking = (FuncName == "pthread_mutex_unlock") || 
                                (FuncName.contains("mutex") && FuncName.contains("unlock"));

              if (isLocking) {
                Value *LockObj = Call->getArgOperand(0);
                if (auto *Inv = dyn_cast<InvokeInst>(Call)) {
                  IRBuilder<> PostBld(&*Inv->getNormalDest()->getFirstInsertionPt());
                  PostBld.CreateCall(SyncLock, {LockObj, CreateInstMetadata(&I, PostBld)});
                } else if (I.getNextNode()) {
                  IRBuilder<> PostBld(I.getNextNode());
                  PostBld.CreateCall(SyncLock, {LockObj, CreateInstMetadata(&I, PostBld)});
                }
                continue;
              }

              if (isUnlocking) {
                IRBuilder<> PreBld(&I);
                Value *LockObj = Call->getArgOperand(0);
                PreBld.CreateCall(SyncUnlock, {LockObj, CreateInstMetadata(&I, PreBld)});
                continue;
              }
            }
          }

          bool SkipInstrumentation = false;
          if (const DebugLoc &DL = I.getDebugLoc()) {
            if (auto *Scope = dyn_cast_or_null<DIScope>(DL.getScope())) {
              StringRef Path = Scope->getFilename();
             
              if (Path.starts_with("/usr/") || Path.starts_with("/lib/")) {
                SkipInstrumentation = true;
              }
            }
          }
          if (SkipInstrumentation) continue;

          IRBuilder<> MemBld(&I);
          if (auto *Load = dyn_cast<LoadInst>(&I)) {
            Value *TargetAddr = Load->getPointerOperand();
            MemBld.CreateCall(MemRead, {TargetAddr, CreateInstMetadata(&I, MemBld)});
          } 
          else if (auto *Store = dyn_cast<StoreInst>(&I)) {
            Value *TargetAddr = Store->getPointerOperand();
            MemBld.CreateCall(MemWrite, {TargetAddr, CreateInstMetadata(&I, MemBld)});
          }
        }
      }
    }
    return PreservedAnalyses::none();
  }
};

} 

extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, 
    "RaceDetectorInstrumentation", 
    LLVM_VERSION_STRING,
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, ModulePassManager &MPM, ArrayRef<PassBuilder::PipelineElement>) {
          if (Name == "fasttrack_pass") {
            MPM.addPass(RaceDetectorPass());
            return true;
          }
          return false;
        }
      );
    }
  };
}
