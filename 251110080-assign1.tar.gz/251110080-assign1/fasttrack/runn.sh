#!/bin/bash

# Exit on any error
set -e

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <source_file.cpp>"
    exit 1
fi

INPUT_FILE=$1
BASENAME=$(basename "$INPUT_FILE" .cpp)

# 1. Configuration - Paths to your built artifacts
# Ensure these files exist in the current directory
PASS_LIB="./fasttrack_pass.so"
RUNTIME_OBJ="./fasttrack.o"
PASS_NAME="fasttrack_pass"

echo "[*] Compiling $INPUT_FILE to LLVM Bitcode..."
# We use -g to preserve debug info for your file-path filtering logic
# -O0 ensures memory accesses aren't optimized away before instrumentation
clang++-20 -c -emit-llvm -O0 -g "$INPUT_FILE" -o "${BASENAME}.bc"

echo "[*] Running FastTrack Pass ($PASS_NAME)..."
# In LLVM 20, the New Pass Manager is used. 
# We load the plugin and specify the pass name in the pipeline.
opt-20 -load-pass-plugin="$PASS_LIB" \
       -passes="$PASS_NAME" \
       "${BASENAME}.bc" -o "${BASENAME}_inst.bc"

echo "[*] Compiling instrumented bitcode to object file..."
clang++-20 -c "${BASENAME}_inst.bc" -o "${BASENAME}_inst.o"

echo "[*] Linking with FastTrack runtime..."
# Link the instrumented code with your runtime and pthreads
clang++-20 "${BASENAME}_inst.o" "$RUNTIME_OBJ" -lpthread -o "${BASENAME}_analyzer"

echo "[*] Analysis Ready: ./${BASENAME}_analyzer"
echo "------------------------------------------------"
./"${BASENAME}_analyzer"
