#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <mutex>
#include <thread>

using std::cout;
using std::endl;
using std::lock_guard;
using std::mutex;
using std::thread;

const uint64_t ITERS = 2;
uint64_t counter = 0;
mutex mtx;

void increment() {
  for (uint64_t i = 0; i < ITERS; ++i) {
    lock_guard<mutex> lock(mtx);
    ++counter;
  }
}

int main() {
  thread t1(increment);
  thread t2(increment);

  t1.join();
  t2.join();

  cout << "Counter value: " << counter << endl;

  return EXIT_SUCCESS;
}
