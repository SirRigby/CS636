#include<bits/stdc++.h>
using namespace std;


class VectorClock {
public:
    unordered_map<int, int> v;

    void increment(int tid) {
        v[tid]++;
    }

    void update(const VectorClock &other) {
        for (auto &p : other.v) {
            v[p.first] = max(v[p.first], p.second);
        }
    }

    bool happens_before(const VectorClock &other) const {
        set<int> keys;
        for (auto &p : v) keys.insert(p.first);
        for (auto &p : other.v) keys.insert(p.first);

        for (int t : keys) {
            int a = v.count(t) ? v.at(t) : 0;
            int b = other.v.count(t) ? other.v.at(t) : 0;
            if (a > b) return false;
        }
        return true;
    }

    bool concurrent(const VectorClock &other) const {
        return !happens_before(other) && !other.happens_before(*this);
    }
};


struct AccessInfo {
    VectorClock vc;
    string ip;
};

struct MemoryMeta {
    unordered_map<int, AccessInfo> reads;
    unordered_map<int, AccessInfo> writes;
};


struct RaceKey {
    string ip1, ip2, addr, type;
    int t1, t2;

    bool operator<(const RaceKey &o) const {
        return tie(ip1, ip2, addr, type, t1, t2) <
               tie(o.ip1, o.ip2, o.addr, o.type, o.t1, o.t2);
    }
};


class DJITPlus {

public:
    unordered_map<int, VectorClock> thread_vc;
    unordered_map<string, VectorClock> lock_vc;
    unordered_map<string, MemoryMeta> memory;

    map<RaceKey, int> races;

    void fork_thread(int parent, int child) {
        thread_vc[child] = thread_vc[parent];
    }

    void join_thread(int parent, int child) {
        thread_vc[parent].update(thread_vc[child]);
    }

    void acquire(int tid, const string &lock) {
        thread_vc[tid].update(lock_vc[lock]);
    }

    void release(int tid, const string &lock) {
        lock_vc[lock] = thread_vc[tid];
        thread_vc[tid].increment(tid);
    }

    void record_race(string ip1, string ip2,
                     string addr, string type,
                     int t1, int t2) {

        if (ip2 < ip1) swap(ip1, ip2);
        if (t2 < t1) swap(t1, t2);

        RaceKey key{ip1, ip2, addr, type, t1, t2};
        races[key]++;
    }

    void read(int tid, const string &addr, const string &ip) {

        VectorClock &vc = thread_vc[tid];
        MemoryMeta &meta = memory[addr];

        for (auto &w : meta.writes) {
            if (w.first != tid &&
                w.second.vc.concurrent(vc)) {

                record_race(w.second.ip, ip, addr,
                            "W-R", w.first, tid);
            }
        }

        meta.reads[tid] = {vc, ip};
        vc.increment(tid);
    }


    void write(int tid, const string &addr, const string &ip) {

        VectorClock &vc = thread_vc[tid];
        MemoryMeta &meta = memory[addr];

        for (auto &w : meta.writes) {
            if (w.first != tid &&
                w.second.vc.concurrent(vc)) {

                record_race(w.second.ip, ip, addr,
                            "W-W", w.first, tid);
            }
        }

        for (auto &r : meta.reads) {
            if (r.first != tid &&
                r.second.vc.concurrent(vc)) {

                record_race(r.second.ip, ip, addr,
                            "R-W", r.first, tid);
            }
        }

        meta.writes[tid] = {vc, ip};
        vc.increment(tid);
    }
};


void process_trace(const string &path, DJITPlus &djit) {

    ifstream file(path);
    string line;

    int parent = 0;

    regex fork_re("Before pthread_create\\(\\) Parent: (\\d+)");
    regex child_begin_re("Child begin: (\\d+)");
    regex child_end_re("Child end: (\\d+)");
    regex acq_re("After acquire TID: (\\d+), address: (0x[0-9a-fA-F]+)");
    regex rel_re("Before release TID: (\\d+), address: (0x[0-9a-fA-F]+)");
    regex mem_re("MEM: TID: (\\d+), IP: (0x[0-9a-fA-F]+), ADDR: (0x[0-9a-fA-F]+).*isRead: (\\d+)");

    smatch m;

    while (getline(file, line)) {

        if (regex_search(line, m, fork_re)) {
            parent = stoi(m[1]);
            continue;
        }

        if (regex_search(line, m, child_begin_re)) {
            int child = stoi(m[1]);
            djit.fork_thread(parent, child);
            continue;
        }

        if (regex_search(line, m, child_end_re)) {
            int child = stoi(m[1]);
            djit.join_thread(parent, child);
            continue;
        }

        if (regex_search(line, m, acq_re)) {
            int tid = stoi(m[1]);
            string lock = m[2];
            djit.acquire(tid, lock);
            continue;
        }

        if (regex_search(line, m, rel_re)) {
            int tid = stoi(m[1]);
            string lock = m[2];
            djit.release(tid, lock);
            continue;
        }

        if (regex_search(line, m, mem_re)) {
            int tid = stoi(m[1]);
            string ip = m[2];
            string addr = m[3];
            bool isRead = stoi(m[4]);

            if (isRead)
                djit.read(tid, addr, ip);
            else
                djit.write(tid, addr, ip);
        }
    }
}


void print_output(const DJITPlus &djit) {

    if (djit.races.empty()) return;

    cout << djit.races.size() << "\n";

    for (auto &r : djit.races) {
        auto key = r.first;
        cout << key.ip1 << "-" << key.ip2 << " "
             << key.addr << " "
             << key.type << " "
             << key.t1 << "-" << key.t2 << " "
             << r.second << "\n";
    }
}


int main(int argc, char *argv[]) {

    if (argc != 2) {
        cout << "Usage: ./djitplus <absolute_trace_path>\n";
        return 1;
    }

    DJITPlus djit;
    process_trace(argv[1], djit);
    print_output(djit);

    return 0;
}
