#!/bin/bash

# Usage: ./runn.bash <program.cpp>

if [ $# -ne 1 ]; then
    echo "Usage: $0 <program.cpp>"
    exit 1
fi

PROG="$1"
BASENAME=$(basename "$PROG" .cpp)

PLUGIN_SRC="fasttrack_pass.cpp"
RUNTIME_SRC="fasttrack.cpp"

# Detect available clang++
if command -v clang++-20 >/dev/null 2>&1; then
    CLANG=clang++-20
    LLVM_VER=20
    echo "[*] Using clang++-20"
elif command -v clang++-19 >/dev/null 2>&1; then
    CLANG=clang++-19
    LLVM_VER=19
    echo "[*] Using clang++-19"
else
    echo "[!] No clang++-19 or clang++-20 found"
    exit 1
fi

# Determine llvm-config for this version
LLVM_CONFIG="llvm-config-$LLVM_VER"

# Plugin and runtime filenames
PASS="./fasttrack_pass.so"
RUNTIME="./fasttrack.o"

# Build plugin if missing or if LLVM version changed
if [ ! -f "$PASS" ]; then
    echo "[*] Building FastTrack LLVM pass for LLVM $LLVM_VER..."
    $CLANG -fPIC -shared "$PLUGIN_SRC" `$LLVM_CONFIG --cxxflags --ldflags --system-libs --libs core passes` -o "$PASS"
    if [ $? -ne 0 ]; then
        echo "[!] Failed to build FastTrack plugin."
        exit 1
    fi
fi

# Build runtime if missing
if [ ! -f "$RUNTIME" ]; then
    echo "[*] Building FastTrack runtime..."
    $CLANG -O0 -c "$RUNTIME_SRC" -o "$RUNTIME"
    if [ $? -ne 0 ]; then
        echo "[!] Failed to build FastTrack runtime."
        exit 1
    fi
fi

# Compile input program to LLVM bitcode with plugin instrumentation
echo "[*] Compiling $PROG to LLVM bitcode with FastTrack instrumentation..."
$CLANG -O0 -emit-llvm -c "$PROG" \
    -Xclang -load -Xclang "$PASS" -fpass-plugin="$PASS" -o "$BASENAME.bc"

if [ $? -ne 0 ]; then
    echo "[!] Compilation failed."
    exit 1
fi

# Link instrumented program with FastTrack runtime
echo "[*] Linking instrumented program with FastTrack runtime..."
$CLANG "$BASENAME.bc" "$RUNTIME" -o "$BASENAME-ft" -pthread

if [ $? -ne 0 ]; then
    echo "[!] Linking failed."
    exit 1
fi

# Run instrumented program
echo "[*] Running instrumented program..."
./"$BASENAME-ft"
